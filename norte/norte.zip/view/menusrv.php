<ol id="menu-srv">
    <li class="btn btn-primary"><a href="?pag=servicos&srv=eletronica" class="cor-w">Eletrônica</a></li>
    <li class="btn btn-primary"><a href="?pag=servicos&srv=infohard" class="cor-w">Info-Hardwere</a></li>
    <li class="btn btn-primary"><a href="?pag=servicos&srv=infosoft" class="cor-w">Info-Software</a></li>
</ol>
