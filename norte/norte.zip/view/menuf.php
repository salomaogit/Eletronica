<div class="post-footer">
    <p class="share-title">Entre em contato conosco pelas redes sociais através dos link´s abaixo:</p>
    <div class="social">
        <div class="social-icons">
            <!-- <p class="share-title">Compartilhar:</p> -->
            <a href="http://www.facebook.com/" class="social-share-link" title="Norte Assistêcia no Facebook"
                data-network-name="facebook">
                <i class="fab fa-facebook-square text"></i>
            </a>
            <a href="http://twitter.com/" class="social-share-link" title="Norte Assistêcia via Twiter"
                data-network-name="twitter">
                <i class="fab fa-twitter-square text"></i>
            </a>
            <a href="https://plus.google.com/" class="social-share-link" title="Norte Assistêcia via Google-Plus"
                data-network-name="googleplus">
                <i class="fab fa-google-plus-square text"></i>
            </a>
            <a href="https://bit.ly/2pXTwc6" class="social-share-link" title="Norte Assistêcia via WhatsApp" data-network-name="pinterest">
                <i class="fab fa-whatsapp-square text"></i>
            </a>
            <a href="http://www.linkedin.com/" class="social-share-link" title="Norte Assistêcia via LinkedIn"
                data-network-name="linkedin">
                <i class="fab fa-linkedin text"></i>
            </a>
            <a href="mailto:norteassistenciatecnica@gmail.com?subject=Bom%20dia!%20Gostaria%20de%20informações!%20Estarei%20no%20aguardo%20de%20um%20retorno." class="social-share-link" title="Norte Assistêcia via Email" 
            data-network-name="basic_email">
                <i class="fas fa-envelope-square text"></i>
            </a>
            <!-- <a href="#" class="social-share-link" title="Compartilhar &quot; 3 maneiras de ter um botão do whatsapp em seu site.&quot; via Print" data-network-name="basic_print" data-share-title="3 maneiras de ter um botão do whatsapp em seu site." data-share-url="https://decisaodigital.com.br/blog/whataspp-no-seu-site/">
                <i class="fas fa-print text"></i>
            </a> -->
        </div>
    </div>
</div> 
<div class="text-center menuf">
    <!-- <h4><a href="mailto:norteassistenciatecnica@gmail.com">norteassistenciatecnica@gmail.com</a></h4> -->
    Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos os direitos reservados | Este site foi criado <i class="fa fa-heart-o" aria-hidden="true"></i> por <a href="https://bit.ly/2PIXBJM" target="_blank">Salomão</a>
</div>